# Dar Mogador — Site multilingue (AR / FR / EN)

Site de restaurant à Essaouira, 3 langues (arabe avec RTL, français, anglais),
réservation via WhatsApp, avis clients modérés, et un dashboard admin complet
pour tout modifier soi-même (textes, plats, prix, photos, WhatsApp, etc.).

## Démarrer en local

```bash
npm install
npm run dev
```

Puis ouvrez l'adresse affichée (en général http://localhost:5173).

## Construire la version de production

```bash
npm run build
```

Cela crée un dossier `dist/` — c'est ce dossier qu'il faut mettre en ligne.

## Mettre le site en ligne sur Netlify (le plus simple)

1. Faites `npm run build` (voir ci-dessus) pour créer le dossier `dist/`.
2. Allez sur https://app.netlify.com/drop
3. Glissez-déposez le dossier `dist/` sur la page.
4. Netlify vous donne une adresse en quelques secondes (ex: `random-name-123.netlify.app`).
5. Dans Netlify, "Site settings" → "Change site name" pour choisir un nom, et
   "Domain settings" si vous avez un nom de domaine à connecter.

### Alternative : connecter le projet à GitHub (mises à jour automatiques)

1. Mettez ce dossier de projet dans un dépôt GitHub.
2. Sur Netlify : "Add new site" → "Import an existing project" → choisissez le dépôt.
3. Build command : `npm run build` — Publish directory : `dist`
   (déjà préconfiguré dans `netlify.toml`).
4. Chaque fois que vous poussez du code sur GitHub, Netlify republie le site.

## Espace admin

Adresse : `/admin/login` (ex: `https://votre-site.netlify.app/admin/login`)

- Email : `hichamlikamt22@gmail.com`
- Mot de passe : `hicham@123`

Depuis le dashboard vous pouvez :
- modifier les textes de l'accueil et de la page "Notre histoire" (dans les 3 langues)
- ajouter / modifier / supprimer les catégories et les plats du menu, avec prix et photo
- ajouter / supprimer des photos de la galerie
- approuver ou masquer les avis clients (les avis soumis par les visiteurs
  n'apparaissent sur le site qu'après votre validation ici)
- consulter la liste des demandes de réservation
- changer le numéro de téléphone affiché, le numéro WhatsApp, l'adresse,
  les horaires, les liens Instagram/Facebook et le lien Google Maps

### Important à savoir sur ce mode admin

Ce site fonctionne **sans base de données externe** : le contenu est stocké
dans le navigateur (localStorage) de l'appareil où vous êtes connecté en
admin. Ça veut dire :
- ça marche tout de suite, sans aucun compte ni configuration supplémentaire ;
- mais si vous modifiez le contenu depuis votre téléphone, ça ne sera pas
  automatiquement visible si vous vous connectez ensuite depuis votre
  ordinateur — chaque appareil garde sa propre copie ;
- si vous videz le cache du navigateur, le contenu revient aux valeurs
  d'origine du fichier `src/data/fallbackContent.js`.

C'est le compromis pour avoir un site 100% fonctionnel sans dépendre d'un
service tiers. Si plus tard vous voulez un vrai compte admin sécurisé (avec
lien reçu par email) et un contenu partagé entre tous vos appareils, il
suffit de connecter une base Supabase (gratuite) :

1. Créez un compte sur https://supabase.com et un nouveau projet.
2. Dans Supabase, créez les tables : `settings`, `home_content`, `about_content`,
   `categories`, `menu_items`, `reviews`, `gallery`, `reservations` (mêmes noms
   de colonnes que dans `src/data/fallbackContent.js`).
3. Sur Netlify : "Site settings" → "Environment variables", ajoutez
   `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` (donnés par Supabase).
4. Redéployez le site — il basculera automatiquement sur Supabase, y compris
   pour l'authentification par email.

Tant que ces deux variables ne sont pas configurées, le site utilise le mode
local décrit plus haut, avec l'email et le mot de passe indiqués ci-dessus.

## Structure du projet

```
src/
  main.jsx, App.jsx       point d'entrée + routes
  i18n/                   traductions AR/FR/EN + contexte de langue
  lib/                    accès aux données (Supabase si connecté, sinon localStorage)
  data/fallbackContent.js contenu de démarrage (modifiable ici en dur si besoin)
  components/             navbar, footer, formulaires, etc.
  pages/                  Accueil, Notre histoire, Menu, Contact
  pages/admin/            dashboard admin complet
```

## Personnaliser rapidement sans passer par l'admin

Le contenu de départ (nom du restaurant, plats, avis, photos...) est dans
`src/data/fallbackContent.js`. Vous pouvez l'éditer directement puis relancer
`npm run build` si vous préférez modifier le contenu "en dur" plutôt que via
le dashboard.
