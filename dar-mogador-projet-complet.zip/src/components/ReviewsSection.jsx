import { useEffect, useState } from "react";
import { useLang } from "../i18n/LanguageContext";
import { getApprovedReviews, submitReview } from "../lib/content";

function Stars({ value }) {
  return <div className="review-stars" aria-label={`${value}/5`}>{"★".repeat(value)}{"☆".repeat(5 - value)}</div>;
}

export default function ReviewsSection() {
  const { t, lang } = useLang();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: "", rating: 5, comment: "" });
  const [status, setStatus] = useState(null); // "success" | "error" | null

  useEffect(() => {
    getApprovedReviews().then((r) => {
      setReviews(r);
      setLoading(false);
    });
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.name || !form.comment) return;
    try {
      await submitReview({ ...form, language: lang });
      setStatus("success");
      setForm({ name: "", rating: 5, comment: "" });
    } catch {
      setStatus("error");
    }
  }

  return (
    <section className="section section-alt">
      <div className="container">
        <div className="section-head">
          <h2>{t.reviews.title}</h2>
        </div>

        {!loading && reviews.length === 0 && <p>{t.reviews.empty}</p>}

        <div className="reviews-grid">
          {reviews.map((r) => (
            <div className="review-card" key={r.id}>
              <Stars value={r.rating} />
              <p className="review-comment">{r.comment}</p>
              <div className="review-name">{r.name}</div>
            </div>
          ))}
        </div>

        <div className="admin-card mt-lg" style={{ maxWidth: 520 }}>
          <h3 style={{ fontSize: "1.2rem" }}>{t.reviews.formTitle}</h3>
          {status === "success" ? (
            <div className="form-success">{t.reviews.success}</div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="field">
                <label htmlFor="rev-name">{t.reviews.name}</label>
                <input
                  id="rev-name"
                  value={form.name}
                  placeholder={t.reviews.namePlaceholder}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                />
              </div>
              <div className="field">
                <label>{t.reviews.rating}</label>
                <div className="star-input">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      type="button"
                      key={n}
                      className={n <= form.rating ? "filled" : ""}
                      onClick={() => setForm((f) => ({ ...f, rating: n }))}
                      aria-label={`${n}/5`}
                    >
                      ★
                    </button>
                  ))}
                </div>
              </div>
              <div className="field">
                <label htmlFor="rev-comment">{t.reviews.comment}</label>
                <textarea
                  id="rev-comment"
                  value={form.comment}
                  placeholder={t.reviews.commentPlaceholder}
                  onChange={(e) => setForm((f) => ({ ...f, comment: e.target.value }))}
                />
              </div>
              {status === "error" && <p className="field-error">{t.reviews.error}</p>}
              <button type="submit" className="btn btn-primary">{t.reviews.submit}</button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
