import { useEffect, useRef, useState } from "react";
import { useLang } from "../i18n/LanguageContext";

export default function LanguageSwitcher() {
  const { lang, setLang, languages } = useLang();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = languages.find((l) => l.code === lang);

  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="lang-switcher lang-switcher-desktop" ref={ref}>
      <button
        className="lang-switcher-trigger"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Change language"
      >
        <span aria-hidden>🌐</span>
        {current?.short}
      </button>
      {open && (
        <div className="lang-menu" role="listbox">
          {languages.map((l) => (
            <button
              key={l.code}
              role="option"
              aria-selected={l.code === lang}
              className={l.code === lang ? "active" : ""}
              onClick={() => {
                setLang(l.code);
                setOpen(false);
              }}
            >
              <span>{l.label}</span>
              {l.code === lang && <span aria-hidden>✓</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function LanguageSwitcherInline({ onSelect }) {
  const { lang, setLang, languages } = useLang();
  return (
    <div className="lang-inline">
      {languages.map((l) => (
        <button
          key={l.code}
          className={l.code === lang ? "active" : ""}
          onClick={() => {
            setLang(l.code);
            onSelect?.();
          }}
        >
          {l.short}
        </button>
      ))}
    </div>
  );
}
