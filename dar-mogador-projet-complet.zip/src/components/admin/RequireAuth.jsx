import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { getSession } from "../../lib/auth";

export default function RequireAuth({ children }) {
  const [status, setStatus] = useState("checking"); // checking | ok | none

  useEffect(() => {
    getSession().then((s) => setStatus(s ? "ok" : "none"));
  }, []);

  if (status === "checking") return null;
  if (status === "none") return <Navigate to="/admin/login" replace />;
  return children;
}
