import { LANGUAGES } from "../../i18n/translations";

export default function AdminLangTabs({ value, onChange }) {
  return (
    <div className="admin-lang-tabs">
      {LANGUAGES.map((l) => (
        <button
          key={l.code}
          type="button"
          className={value === l.code ? "active" : ""}
          onClick={() => onChange(l.code)}
        >
          {l.label}
        </button>
      ))}
    </div>
  );
}
