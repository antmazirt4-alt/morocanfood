import { Helmet } from "react-helmet-async";
import { useLocation } from "react-router-dom";
import { useLang } from "../i18n/LanguageContext";

const SITE_URL = typeof window !== "undefined" ? window.location.origin : "";

export default function SEO({ title, description }) {
  const { lang } = useLang();
  const { pathname } = useLocation();

  return (
    <Helmet>
      <html lang={lang} dir={lang === "ar" ? "rtl" : "ltr"} />
      <title>{title}</title>
      {description && <meta name="description" content={description} />}
      <link rel="alternate" hrefLang="ar" href={`${SITE_URL}${pathname}?lang=ar`} />
      <link rel="alternate" hrefLang="fr" href={`${SITE_URL}${pathname}?lang=fr`} />
      <link rel="alternate" hrefLang="en" href={`${SITE_URL}${pathname}?lang=en`} />
      <link rel="alternate" hrefLang="x-default" href={`${SITE_URL}${pathname}`} />
      <meta property="og:title" content={title} />
      {description && <meta property="og:description" content={description} />}
      <meta property="og:locale" content={lang} />
    </Helmet>
  );
}
