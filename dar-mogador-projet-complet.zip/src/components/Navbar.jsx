import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useLang } from "../i18n/LanguageContext";
import LanguageSwitcher, { LanguageSwitcherInline } from "./LanguageSwitcher";

export default function Navbar({ restaurantName }) {
  const { t } = useLang();
  const [open, setOpen] = useState(false);

  const links = [
    { to: "/", label: t.nav.home },
    { to: "/about", label: t.nav.about },
    { to: "/menu", label: t.nav.menu },
    { to: "/contact", label: t.nav.contact },
  ];

  return (
    <header className="navbar">
      <div className="container">
        <NavLink to="/" className="navbar-brand" onClick={() => setOpen(false)}>
          {restaurantName}
        </NavLink>
        <nav>
          <ul className="navbar-links">
            {links.map((l) => (
              <li key={l.to}>
                <NavLink to={l.to} end={l.to === "/"} className={({ isActive }) => (isActive ? "active" : "")}>
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <div className="navbar-right">
          <LanguageSwitcher />
          <NavLink to="/contact" className="btn btn-primary btn-sm">
            {t.nav.reserve}
          </NavLink>
          <button
            className="navbar-burger"
            aria-label="Menu"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            <span />
          </button>
        </div>
      </div>
      <div className={`mobile-panel ${open ? "open" : ""}`}>
        <div className="container">
          <ul>
            {links.map((l) => (
              <li key={l.to}>
                <NavLink to={l.to} end={l.to === "/"} onClick={() => setOpen(false)}>
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <LanguageSwitcherInline onSelect={() => setOpen(false)} />
        </div>
      </div>
    </header>
  );
}
