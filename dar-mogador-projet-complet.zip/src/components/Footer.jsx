import { Link } from "react-router-dom";
import { useLang, pick } from "../i18n/LanguageContext";

export default function Footer({ settings }) {
  const { t, lang } = useLang();
  if (!settings) return null;

  const name = pick(settings, "restaurant_name", lang);
  const address = pick(settings, "address", lang);
  const hours = pick(settings, "hours", lang);

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="footer-brand">{name}</div>
            <p style={{ color: "rgba(251,248,242,0.7)", maxWidth: "34ch" }}>
              {pick(settings, "tagline", lang)}
            </p>
          </div>
          <div>
            <h4>{t.footer.quickLinks}</h4>
            <ul>
              <li><Link to="/">{t.nav.home}</Link></li>
              <li><Link to="/about">{t.nav.about}</Link></li>
              <li><Link to="/menu">{t.nav.menu}</Link></li>
              <li><Link to="/contact">{t.nav.contact}</Link></li>
            </ul>
          </div>
          <div>
            <h4>{t.contact.title}</h4>
            <ul>
              <li>{address}</li>
              <li>{hours}</li>
              <li>{settings.phone_display}</li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} {name} — {t.footer.rights}</span>
          <span style={{ display: "flex", gap: 14 }}>
            {settings.instagram_url && <a href={settings.instagram_url} target="_blank" rel="noreferrer">Instagram</a>}
            {settings.facebook_url && <a href={settings.facebook_url} target="_blank" rel="noreferrer">Facebook</a>}
          </span>
        </div>
      </div>
    </footer>
  );
}
