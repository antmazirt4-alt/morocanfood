import { useLang } from "../i18n/LanguageContext";

export default function Loader() {
  const { t } = useLang();
  return (
    <div className="container" style={{ padding: "80px 28px", textAlign: "center", color: "rgba(28,23,18,0.5)" }}>
      {t.messages.loading}
    </div>
  );
}
