import { useState } from "react";
import { useLang } from "../i18n/LanguageContext";
import { logReservation } from "../lib/content";

export default function ReservationForm({ whatsappNumber }) {
  const { t, lang } = useLang();
  const [form, setForm] = useState({ name: "", phone: "", guests: 2, date: "", time: "", notes: "" });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function validate() {
    const e = {};
    ["name", "phone", "date", "time"].forEach((f) => {
      if (!form[f]) e[f] = t.reservation.required;
    });
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(ev) {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    const message = t.reservation.whatsappMessage(form);
    try {
      await logReservation({
        name: form.name,
        phone: form.phone,
        guests: Number(form.guests),
        date: form.date,
        time: form.time,
        notes: form.notes,
        language: lang,
        created_at: new Date().toISOString(),
      });
    } catch {
      // Non-blocking: the WhatsApp handoff still works even if logging fails.
    }
    const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    setSent(true);
    setSubmitting(false);
    window.open(url, "_blank", "noopener,noreferrer");
  }

  if (sent) {
    return <div className="form-success">{t.reservation.success}</div>;
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div className="form-grid">
        <div className="field">
          <label htmlFor="res-name">{t.reservation.name}</label>
          <input
            id="res-name"
            value={form.name}
            placeholder={t.reservation.namePlaceholder}
            onChange={(e) => update("name", e.target.value)}
          />
          {errors.name && <span className="field-error">{errors.name}</span>}
        </div>
        <div className="field">
          <label htmlFor="res-phone">{t.reservation.phone}</label>
          <input
            id="res-phone"
            value={form.phone}
            placeholder={t.reservation.phonePlaceholder}
            onChange={(e) => update("phone", e.target.value)}
          />
          {errors.phone && <span className="field-error">{errors.phone}</span>}
        </div>
        <div className="field">
          <label htmlFor="res-guests">{t.reservation.guests}</label>
          <select id="res-guests" value={form.guests} onChange={(e) => update("guests", e.target.value)}>
            {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="res-date">{t.reservation.date}</label>
          <input
            id="res-date"
            type="date"
            value={form.date}
            onChange={(e) => update("date", e.target.value)}
          />
          {errors.date && <span className="field-error">{errors.date}</span>}
        </div>
        <div className="field">
          <label htmlFor="res-time">{t.reservation.time}</label>
          <input
            id="res-time"
            type="time"
            value={form.time}
            onChange={(e) => update("time", e.target.value)}
          />
          {errors.time && <span className="field-error">{errors.time}</span>}
        </div>
      </div>
      <div className="field">
        <label htmlFor="res-notes">{t.reservation.notes}</label>
        <textarea
          id="res-notes"
          value={form.notes}
          placeholder={t.reservation.notesPlaceholder}
          onChange={(e) => update("notes", e.target.value)}
        />
      </div>
      <button type="submit" className="btn btn-primary btn-block" disabled={submitting}>
        {t.reservation.submit}
      </button>
    </form>
  );
}
