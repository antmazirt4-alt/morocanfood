import { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import { useLang, pick } from "../i18n/LanguageContext";
import { getSettings } from "../lib/content";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function Layout() {
  const { lang } = useLang();
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  return (
    <>
      <Navbar restaurantName={settings ? pick(settings, "restaurant_name", lang) : "\u00A0"} />
      <main>
        <Outlet />
      </main>
      <Footer settings={settings} />
    </>
  );
}
