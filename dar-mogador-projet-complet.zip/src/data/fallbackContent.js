// This content is shown until Supabase is connected (see README) and lets the
// site run and look complete immediately after deploy. Once Supabase is wired
// up, everything here is edited from /admin instead.

export const fallbackSettings = {
  restaurant_name_ar: "دار نجمة",
  restaurant_name_fr: "Dar Najma",
  restaurant_name_en: "Dar Najma",
  tagline_ar: "مطبخ مغربي أصيل في قلب مراكش",
  tagline_fr: "Cuisine marocaine authentique au cœur de Marrakech",
  tagline_en: "Authentic Moroccan cooking in the heart of Marrakesh",
  phone_display: "+212 6 00 00 00 00",
  whatsapp_number: "212600000000",
  address_ar: "درب الشتوي، رياض زيتون، مراكش",
  address_fr: "Derb Chtouka, Riad Zitoun, Marrakech",
  address_en: "Derb Chtouka, Riad Zitoun, Marrakesh",
  hours_ar: "كل يوم من 12:00 إلى 23:00",
  hours_fr: "Tous les jours de 12h00 à 23h00",
  hours_en: "Every day, 12:00 PM – 11:00 PM",
  instagram_url: "https://instagram.com",
  facebook_url: "https://facebook.com",
  map_embed_url:
    "https://www.google.com/maps?q=Marrakesh+Morocco&output=embed",
  default_language: "fr",
};

export const fallbackHome = {
  hero_title_ar: "دار نجمة",
  hero_title_fr: "Dar Najma",
  hero_title_en: "Dar Najma",
  hero_subtitle_ar: "مطبخ مغربي أصيل في قلب مراكش",
  hero_subtitle_fr: "Cuisine marocaine authentique au cœur de Marrakech",
  hero_subtitle_en: "Authentic Moroccan cooking in the heart of Marrakesh",
  hero_description_ar:
    "وصفات عائلية توارثناها منذ ثلاثة أجيال، طُبخت ببطء على الفحم وقُدّمت في رياض هادئ بين أشجار البرتقال.",
  hero_description_fr:
    "Des recettes familiales transmises depuis trois générations, cuisinées lentement au charbon et servies dans un riad paisible, entre les orangers.",
  hero_description_en:
    "Family recipes passed down over three generations, cooked slowly over charcoal and served in a quiet riad among orange trees.",
  story_teaser_ar:
    "بدأت دار نجمة سنة 1998 كمطبخ صغير داخل بيت العائلة، قبل أن تصبح وجهة يقصدها أهل مراكش وزوارها لتذوق المطبخ المغربي كما يُطهى في البيوت.",
  story_teaser_fr:
    "Dar Najma a débuté en 1998, dans la cuisine familiale, avant de devenir une adresse incontournable pour les Marrakchis comme pour les visiteurs en quête d'une cuisine marocaine maison.",
  story_teaser_en:
    "Dar Najma began in 1998 in a family kitchen, before growing into a place Marrakshis and visitors alike come to for Moroccan food the way it's cooked at home.",
};

export const fallbackAbout = {
  title_ar: "قصتنا",
  title_fr: "Notre histoire",
  title_en: "Our Story",
  body_ar:
    "في سنة 1998، بدأت للا نجمة تطبخ لجيرانها في درب صغير برياض زيتون. كانت قدورها لا تكفي الطلبات، فحوّلت غرفة الضيوف إلى مطعم صغير بست طاولات فقط.\n\nاليوم، يواصل أبناؤها الوصفة نفسها: طاجين بالفحم، خبز يُعجن كل صباح، وتوابل تُطحن يدوياً. لم يتغير شيء سوى عدد من يجلس حول الطاولة.\n\nنستقبلكم في رياض هادئ بين جدران قرميدية وأشجار برتقال، لتذوقوا مطبخاً مغربياً كما يُطهى في البيوت، لا كما يُقدَّم للسياح.",
  body_fr:
    "En 1998, Lalla Najma a commencé à cuisiner pour ses voisins dans une petite derb du Riad Zitoun. Ses marmites ne suffisaient plus, alors elle a transformé le salon familial en un petit restaurant de six tables.\n\nAujourd'hui, ses enfants perpétuent la même recette : tajines cuits au charbon, pain pétri chaque matin, épices moulues à la main. Rien n'a changé, sinon le nombre de convives autour de la table.\n\nNous vous accueillons dans un riad paisible, entre murs de brique et orangers, pour une cuisine marocaine pensée pour la maison — pas pour les cars de touristes.",
  body_en:
    "In 1998, Lalla Najma began cooking for her neighbours in a small derb in Riad Zitoun. Her pots could no longer keep up, so she turned the family sitting room into a six-table restaurant.\n\nToday her children carry on the same recipe: tagines cooked over charcoal, bread kneaded fresh each morning, spices ground by hand. Nothing has changed except how many people now sit around the table.\n\nWe welcome you into a quiet riad among brick walls and orange trees, for Moroccan cooking made the way it's cooked at home — not for tour buses.",
  photo_url:
    "https://images.unsplash.com/photo-1489493887464-892be6d1daae?q=80&w=1200&auto=format&fit=crop",
};

export const fallbackCategories = [
  { id: "c1", sort_order: 1, name_ar: "المقبلات", name_fr: "Entrées", name_en: "Starters" },
  { id: "c2", sort_order: 2, name_ar: "الأطباق الرئيسية", name_fr: "Plats principaux", name_en: "Mains" },
  { id: "c3", sort_order: 3, name_ar: "الحلويات", name_fr: "Desserts", name_en: "Desserts" },
  { id: "c4", sort_order: 4, name_ar: "المشروبات", name_fr: "Boissons", name_en: "Drinks" },
];

export const fallbackMenuItems = [
  {
    id: "m1",
    category_id: "c1",
    sort_order: 1,
    is_available: true,
    price: 45,
    image_url:
      "https://images.unsplash.com/photo-1633945274309-2c661b34a4ba?q=80&w=800&auto=format&fit=crop",
    name_ar: "سلطة مغربية مشوية",
    name_fr: "Salade marocaine grillée",
    name_en: "Grilled Moroccan Salad",
    description_ar: "طماطم وفلفل مشوي، ثوم، كمون وزيت الزيتون",
    description_fr: "Tomates et poivrons grillés, ail, cumin et huile d'olive",
    description_en: "Grilled tomato and pepper, garlic, cumin and olive oil",
  },
  {
    id: "m2",
    category_id: "c1",
    sort_order: 2,
    is_available: true,
    price: 55,
    image_url:
      "https://images.unsplash.com/photo-1615937691194-97dbd3f3dc29?q=80&w=800&auto=format&fit=crop",
    name_ar: "بريوات باللحم",
    name_fr: "Briouates à la viande",
    name_en: "Meat Briouates",
    description_ar: "عجينة ورقة محشوة باللحم المفروم والبصل والبقدونس",
    description_fr: "Feuille de brick farcie à la viande hachée, oignon et persil",
    description_en: "Crispy pastry filled with minced meat, onion and parsley",
  },
  {
    id: "m3",
    category_id: "c2",
    sort_order: 1,
    is_available: true,
    price: 120,
    image_url:
      "https://images.unsplash.com/photo-1591127302397-a2d9f7e3e1e1?q=80&w=800&auto=format&fit=crop",
    name_ar: "طاجين اللحم بالبرقوق واللوز",
    name_fr: "Tajine d'agneau aux pruneaux et amandes",
    name_en: "Lamb Tagine with Prunes and Almonds",
    description_ar: "لحم غنم مطهو ببطء مع البرقوق واللوز المحمّص والقرفة",
    description_fr: "Agneau mijoté longuement avec pruneaux, amandes grillées et cannelle",
    description_en: "Lamb slow-cooked with prunes, toasted almonds and cinnamon",
  },
  {
    id: "m4",
    category_id: "c2",
    sort_order: 2,
    is_available: true,
    price: 95,
    image_url:
      "https://images.unsplash.com/photo-1585937421612-70a008356c36?q=80&w=800&auto=format&fit=crop",
    name_ar: "كسكس بالخضر السبعة",
    name_fr: "Couscous aux sept légumes",
    name_en: "Seven-Vegetable Couscous",
    description_ar: "كسكس مغربي تقليدي يقدم يوم الجمعة مع مرقة الخضر",
    description_fr: "Couscous traditionnel du vendredi, servi avec son bouillon de légumes",
    description_en: "Traditional Friday couscous, served with vegetable broth",
  },
  {
    id: "m5",
    category_id: "c3",
    sort_order: 1,
    is_available: true,
    price: 40,
    image_url:
      "https://images.unsplash.com/photo-1519676867240-f03562e64548?q=80&w=800&auto=format&fit=crop",
    name_ar: "شباكية بالعسل",
    name_fr: "Chebakia au miel",
    name_en: "Honey Chebakia",
    description_ar: "حلوى مقرمشة مغموسة بالعسل ومرشوشة بالسمسم",
    description_fr: "Pâtisserie croustillante trempée au miel et graines de sésame",
    description_en: "Crisp pastry dipped in honey and sesame seeds",
  },
  {
    id: "m6",
    category_id: "c4",
    sort_order: 1,
    is_available: true,
    price: 20,
    image_url:
      "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?q=80&w=800&auto=format&fit=crop",
    name_ar: "أتاي مغربي بالنعناع",
    name_fr: "Thé marocain à la menthe",
    name_en: "Moroccan Mint Tea",
    description_ar: "شاي أخضر بالنعناع الطازج، يُصب من الأعلى تقليدياً",
    description_fr: "Thé vert à la menthe fraîche, servi à la traditionnelle",
    description_en: "Green tea with fresh mint, poured the traditional way",
  },
];

export const fallbackReviews = [
  {
    id: "r1",
    name: "Sophie M.",
    rating: 5,
    comment:
      "Un accueil chaleureux et un tajine aux pruneaux inoubliable. On se croirait invité chez une famille marrakchie.",
    language: "fr",
    approved: true,
    created_at: "2026-06-02",
  },
  {
    id: "r2",
    name: "James H.",
    rating: 5,
    comment:
      "Best meal we had in Marrakesh. The riad courtyard at night is magical, and the couscous was outstanding.",
    language: "en",
    approved: true,
    created_at: "2026-05-18",
  },
  {
    id: "r3",
    name: "يوسف الإدريسي",
    rating: 4,
    comment: "طعم أصيل يذكرني بمطبخ جدتي، والخدمة كانت راقية جداً.",
    language: "ar",
    approved: true,
    created_at: "2026-04-30",
  },
];

export const fallbackGallery = [
  {
    id: "g1",
    image_url:
      "https://images.unsplash.com/photo-1594221708779-94832f4320d1?q=80&w=900&auto=format&fit=crop",
    caption_ar: "فناء الرياض",
    caption_fr: "La cour du riad",
    caption_en: "The riad courtyard",
  },
  {
    id: "g2",
    image_url:
      "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?q=80&w=900&auto=format&fit=crop",
    caption_ar: "طاجين على الفحم",
    caption_fr: "Tajine cuit au charbon",
    caption_en: "Tagine over charcoal",
  },
  {
    id: "g3",
    image_url:
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=900&auto=format&fit=crop",
    caption_ar: "أتاي بالنعناع",
    caption_fr: "Thé à la menthe",
    caption_en: "Mint tea",
  },
];
