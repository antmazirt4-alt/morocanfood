import { useEffect, useState } from "react";
import { useLang } from "../../i18n/LanguageContext";
import { getAbout, updateAbout } from "../../lib/content";
import AdminLangTabs from "../../components/admin/AdminLangTabs";

export default function AdminAbout() {
  const { t } = useLang();
  const [form, setForm] = useState(null);
  const [tab, setTab] = useState("ar");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getAbout().then(setForm);
  }, []);

  if (!form) return null;

  function field(key) {
    return `${key}_${tab}`;
  }

  async function handleSave(e) {
    e.preventDefault();
    await updateAbout(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div>
      <div className="admin-header">
        <h1 style={{ margin: 0 }}>{t.admin.about}</h1>
        {saved && <span className="badge badge-approved">{t.admin.saved}</span>}
      </div>

      <AdminLangTabs value={tab} onChange={setTab} />

      <form onSubmit={handleSave} className="admin-card">
        <div className="field">
          <label>Page title</label>
          <input
            value={form[field("title")] || ""}
            onChange={(e) => setForm({ ...form, [field("title")]: e.target.value })}
          />
        </div>
        <div className="field">
          <label>Story text</label>
          <textarea
            rows={10}
            value={form[field("body")] || ""}
            onChange={(e) => setForm({ ...form, [field("body")]: e.target.value })}
          />
        </div>
        <div className="field">
          <label>{t.admin.image}</label>
          <input
            value={form.photo_url || ""}
            onChange={(e) => setForm({ ...form, photo_url: e.target.value })}
          />
        </div>
        <button type="submit" className="btn btn-primary">{t.admin.save}</button>
      </form>
    </div>
  );
}
