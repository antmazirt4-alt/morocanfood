import { useEffect, useState } from "react";
import { useLang } from "../../i18n/LanguageContext";
import { listReservations } from "../../lib/content";

export default function AdminReservations() {
  const { t } = useLang();
  const [rows, setRows] = useState([]);

  useEffect(() => {
    listReservations().then(setRows);
  }, []);

  return (
    <div>
      <div className="admin-header">
        <h1 style={{ margin: 0 }}>{t.admin.reservations}</h1>
      </div>
      <p style={{ fontSize: "0.85rem", color: "rgba(28,23,18,0.6)", maxWidth: "60ch" }}>
        Reservations are confirmed directly on WhatsApp. This is a read-only log of requests sent
        from the website, kept for your records.
      </p>
      <div className="admin-card">
        {rows.length === 0 ? (
          <p>—</p>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>Name</th><th>Phone</th><th>Guests</th><th>Date</th><th>Time</th><th>Lang</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td>{r.name}</td>
                  <td>{r.phone}</td>
                  <td>{r.guests}</td>
                  <td>{r.date}</td>
                  <td>{r.time}</td>
                  <td>{r.language?.toUpperCase()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
