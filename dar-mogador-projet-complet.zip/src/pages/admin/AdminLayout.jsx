import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useLang } from "../../i18n/LanguageContext";
import { signOut } from "../../lib/auth";
import { isSupabaseConfigured } from "../../lib/supabase";

export default function AdminLayout() {
  const { t } = useLang();
  const navigate = useNavigate();

  async function handleLogout() {
    await signOut();
    navigate("/admin/login");
  }

  const links = [
    { to: "/admin", label: t.admin.home, end: true },
    { to: "/admin/about", label: t.admin.about },
    { to: "/admin/menu", label: t.admin.menuMgmt },
    { to: "/admin/gallery", label: t.admin.gallery },
    { to: "/admin/reviews", label: t.admin.reviewsMgmt },
    { to: "/admin/reservations", label: t.admin.reservations },
    { to: "/admin/settings", label: t.admin.settings },
  ];

  return (
    <div className="admin-shell" dir="ltr">
      <aside className="admin-sidebar">
        <div className="brand">Dar Najma — {t.admin.dashboard}</div>
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.end} className={({ isActive }) => (isActive ? "active" : "")}>
            {l.label}
          </NavLink>
        ))}
        <button onClick={handleLogout} style={{ marginTop: 20 }}>{t.admin.logout}</button>
      </aside>
      <div style={{ flex: 1 }}>
        {!isSupabaseConfigured && (
          <div className="demo-banner">
            Demo mode — changes are saved to this browser only. Connect Supabase (see README) to persist
            content for real visitors and manage it from any device.
          </div>
        )}
        <main className="admin-main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
