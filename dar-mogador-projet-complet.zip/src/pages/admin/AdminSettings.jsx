import { useEffect, useState } from "react";
import { useLang } from "../../i18n/LanguageContext";
import { getSettings, updateSettings } from "../../lib/content";
import AdminLangTabs from "../../components/admin/AdminLangTabs";
import { LANGUAGES } from "../../i18n/translations";

export default function AdminSettings() {
  const { t } = useLang();
  const [form, setForm] = useState(null);
  const [tab, setTab] = useState("ar");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getSettings().then(setForm);
  }, []);

  if (!form) return null;

  function field(key) {
    return `${key}_${tab}`;
  }

  async function handleSave(e) {
    e.preventDefault();
    await updateSettings(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div>
      <div className="admin-header">
        <h1 style={{ margin: 0 }}>{t.admin.settings}</h1>
        {saved && <span className="badge badge-approved">{t.admin.saved}</span>}
      </div>

      <form onSubmit={handleSave}>
        <div className="admin-card">
          <h3 style={{ fontSize: "1.05rem" }}>{t.admin.defaultLanguage}</h3>
          <p style={{ fontSize: "0.85rem", color: "rgba(28,23,18,0.6)" }}>
            Used for first-time visitors whose browser language isn't Arabic, French or English.
          </p>
          <div className="field" style={{ maxWidth: 240 }}>
            <select
              value={form.default_language}
              onChange={(e) => setForm({ ...form, default_language: e.target.value })}
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>{l.label}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="admin-card">
          <h3 style={{ fontSize: "1.05rem" }}>{t.admin.restaurantName} &amp; identity</h3>
          <AdminLangTabs value={tab} onChange={setTab} />
          <div className="field">
            <label>{t.admin.restaurantName}</label>
            <input
              value={form[field("restaurant_name")] || ""}
              onChange={(e) => setForm({ ...form, [field("restaurant_name")]: e.target.value })}
            />
          </div>
          <div className="field">
            <label>Tagline</label>
            <input
              value={form[field("tagline")] || ""}
              onChange={(e) => setForm({ ...form, [field("tagline")]: e.target.value })}
            />
          </div>
          <div className="field">
            <label>{t.contact.address}</label>
            <input
              value={form[field("address")] || ""}
              onChange={(e) => setForm({ ...form, [field("address")]: e.target.value })}
            />
          </div>
          <div className="field">
            <label>{t.contact.hours}</label>
            <input
              value={form[field("hours")] || ""}
              onChange={(e) => setForm({ ...form, [field("hours")]: e.target.value })}
            />
          </div>
        </div>

        <div className="admin-card">
          <h3 style={{ fontSize: "1.05rem" }}>Contact &amp; WhatsApp</h3>
          <div className="form-grid">
            <div className="field">
              <label>Displayed phone number</label>
              <input value={form.phone_display || ""} onChange={(e) => setForm({ ...form, phone_display: e.target.value })} />
            </div>
            <div className="field">
              <label>WhatsApp number (digits only, with country code)</label>
              <input value={form.whatsapp_number || ""} onChange={(e) => setForm({ ...form, whatsapp_number: e.target.value })} />
            </div>
            <div className="field">
              <label>Instagram URL</label>
              <input value={form.instagram_url || ""} onChange={(e) => setForm({ ...form, instagram_url: e.target.value })} />
            </div>
            <div className="field">
              <label>Facebook URL</label>
              <input value={form.facebook_url || ""} onChange={(e) => setForm({ ...form, facebook_url: e.target.value })} />
            </div>
          </div>
          <div className="field">
            <label>Google Maps embed URL</label>
            <input value={form.map_embed_url || ""} onChange={(e) => setForm({ ...form, map_embed_url: e.target.value })} />
          </div>
        </div>

        <button type="submit" className="btn btn-primary">{t.admin.save}</button>
      </form>
    </div>
  );
}
