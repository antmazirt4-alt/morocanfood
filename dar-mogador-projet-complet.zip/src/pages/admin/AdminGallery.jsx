import { useEffect, useState } from "react";
import { useLang } from "../../i18n/LanguageContext";
import { getGallery, saveGalleryImage, deleteGalleryImage } from "../../lib/content";
import AdminLangTabs from "../../components/admin/AdminLangTabs";

const emptyImage = {
  image_url: "",
  sort_order: 1,
  caption_ar: "",
  caption_fr: "",
  caption_en: "",
};

export default function AdminGallery() {
  const { t } = useLang();
  const [images, setImages] = useState([]);
  const [editing, setEditing] = useState(null);
  const [tab, setTab] = useState("ar");

  async function refresh() {
    setImages(await getGallery());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleSave(e) {
    e.preventDefault();
    await saveGalleryImage(editing);
    setEditing(null);
    refresh();
  }

  async function handleDelete(id) {
    if (!confirm(t.admin.confirmDelete)) return;
    await deleteGalleryImage(id);
    refresh();
  }

  return (
    <div>
      <div className="admin-header">
        <h1 style={{ margin: 0 }}>{t.admin.gallery}</h1>
        <button
          className="btn btn-outline btn-sm"
          onClick={() => setEditing({ ...emptyImage, sort_order: images.length + 1 })}
        >
          + {t.admin.addImage}
        </button>
      </div>

      <div className="admin-card">
        <table className="admin-table">
          <thead>
            <tr>
              <th>{t.admin.image}</th>
              <th>{t.admin.caption}</th>
              <th>#</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {images.map((g) => (
              <tr key={g.id}>
                <td>
                  <div style={{ width: 64, height: 44, borderRadius: 3, overflow: "hidden", background: "var(--sand-deep)" }}>
                    {g.image_url && <img src={g.image_url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
                  </div>
                </td>
                <td>{g.caption_fr || g.caption_en || g.caption_ar}</td>
                <td>{g.sort_order}</td>
                <td className="admin-row-actions">
                  <button className="btn btn-outline btn-sm" onClick={() => setEditing(g)}>{t.admin.edit}</button>
                  <button className="btn btn-outline btn-sm" onClick={() => handleDelete(g.id)}>{t.admin.delete}</button>
                </td>
              </tr>
            ))}
            {images.length === 0 && (
              <tr><td colSpan={4}>—</td></tr>
            )}
          </tbody>
        </table>

        {editing && (
          <form onSubmit={handleSave} className="admin-card" style={{ marginTop: 16 }}>
            <div className="field">
              <label>{t.admin.image} URL</label>
              <input
                value={editing.image_url}
                onChange={(e) => setEditing({ ...editing, image_url: e.target.value })}
                placeholder="https://..."
                required
              />
            </div>
            <div className="field" style={{ maxWidth: 160 }}>
              <label>Sort order</label>
              <input
                type="number"
                value={editing.sort_order}
                onChange={(e) => setEditing({ ...editing, sort_order: Number(e.target.value) })}
              />
            </div>
            <AdminLangTabs value={tab} onChange={setTab} />
            <div className="field">
              <label>{t.admin.caption}</label>
              <input
                value={editing[`caption_${tab}`] || ""}
                onChange={(e) => setEditing({ ...editing, [`caption_${tab}`]: e.target.value })}
              />
            </div>
            <div className="admin-row-actions">
              <button type="submit" className="btn btn-primary">{t.admin.save}</button>
              <button type="button" className="btn btn-outline" onClick={() => setEditing(null)}>{t.admin.cancel}</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
