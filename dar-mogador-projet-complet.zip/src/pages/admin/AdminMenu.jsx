import { useEffect, useState } from "react";
import { useLang, pick } from "../../i18n/LanguageContext";
import {
  getCategories,
  saveCategory,
  deleteCategory,
  getMenuItems,
  saveMenuItem,
  deleteMenuItem,
} from "../../lib/content";
import AdminLangTabs from "../../components/admin/AdminLangTabs";

const emptyItem = {
  category_id: "",
  price: "",
  image_url: "",
  is_available: true,
  sort_order: 1,
  name_ar: "", name_fr: "", name_en: "",
  description_ar: "", description_fr: "", description_en: "",
};

const emptyCategory = { name_ar: "", name_fr: "", name_en: "", sort_order: 1 };

export default function AdminMenu() {
  const { t, lang } = useLang();
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [tab, setTab] = useState("ar");
  const [editingItem, setEditingItem] = useState(null);
  const [editingCategory, setEditingCategory] = useState(null);

  async function refresh() {
    setCategories(await getCategories());
    setItems(await getMenuItems());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleSaveItem(e) {
    e.preventDefault();
    await saveMenuItem({ ...editingItem, price: Number(editingItem.price) });
    setEditingItem(null);
    refresh();
  }

  async function handleSaveCategory(e) {
    e.preventDefault();
    await saveCategory(editingCategory);
    setEditingCategory(null);
    refresh();
  }

  async function handleDeleteItem(id) {
    if (!confirm(t.admin.confirmDelete)) return;
    await deleteMenuItem(id);
    refresh();
  }

  async function handleDeleteCategory(id) {
    if (!confirm(t.admin.confirmDelete)) return;
    await deleteCategory(id);
    refresh();
  }

  return (
    <div>
      <div className="admin-header">
        <h1 style={{ margin: 0 }}>{t.admin.menuMgmt}</h1>
      </div>

      {/* Categories */}
      <div className="admin-card">
        <div className="admin-header">
          <h3 style={{ margin: 0, fontSize: "1.05rem" }}>{t.admin.category}</h3>
          <button className="btn btn-outline btn-sm" onClick={() => setEditingCategory({ ...emptyCategory })}>
            + {t.admin.add}
          </button>
        </div>
        <table className="admin-table">
          <thead>
            <tr><th>AR</th><th>FR</th><th>EN</th><th>#</th><th></th></tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id}>
                <td>{c.name_ar}</td>
                <td>{c.name_fr}</td>
                <td>{c.name_en}</td>
                <td>{c.sort_order}</td>
                <td className="admin-row-actions">
                  <button className="btn btn-outline btn-sm" onClick={() => setEditingCategory(c)}>{t.admin.edit}</button>
                  <button className="btn btn-outline btn-sm" onClick={() => handleDeleteCategory(c.id)}>{t.admin.delete}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {editingCategory && (
          <form onSubmit={handleSaveCategory} className="admin-card" style={{ marginTop: 16 }}>
            <div className="form-grid">
              <div className="field"><label>Arabic name</label>
                <input value={editingCategory.name_ar} onChange={(e) => setEditingCategory({ ...editingCategory, name_ar: e.target.value })} required />
              </div>
              <div className="field"><label>French name</label>
                <input value={editingCategory.name_fr} onChange={(e) => setEditingCategory({ ...editingCategory, name_fr: e.target.value })} required />
              </div>
              <div className="field"><label>English name</label>
                <input value={editingCategory.name_en} onChange={(e) => setEditingCategory({ ...editingCategory, name_en: e.target.value })} required />
              </div>
              <div className="field"><label>Sort order</label>
                <input type="number" value={editingCategory.sort_order} onChange={(e) => setEditingCategory({ ...editingCategory, sort_order: Number(e.target.value) })} />
              </div>
            </div>
            <div className="admin-row-actions">
              <button type="submit" className="btn btn-primary">{t.admin.save}</button>
              <button type="button" className="btn btn-outline" onClick={() => setEditingCategory(null)}>{t.admin.cancel}</button>
            </div>
          </form>
        )}
      </div>

      {/* Menu items */}
      <div className="admin-card">
        <div className="admin-header">
          <h3 style={{ margin: 0, fontSize: "1.05rem" }}>{t.admin.dishName}</h3>
          <button
            className="btn btn-outline btn-sm"
            onClick={() => setEditingItem({ ...emptyItem, category_id: categories[0]?.id || "" })}
          >
            + {t.admin.add}
          </button>
        </div>
        <table className="admin-table">
          <thead>
            <tr><th>{t.admin.dishName}</th><th>{t.admin.category}</th><th>{t.admin.price}</th><th>{t.admin.available}</th><th></th></tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.id}>
                <td>{pick(item, "name", lang)}</td>
                <td>{pick(categories.find((c) => c.id === item.category_id), "name", lang)}</td>
                <td>{item.price}</td>
                <td>{item.is_available !== false ? "✓" : "—"}</td>
                <td className="admin-row-actions">
                  <button className="btn btn-outline btn-sm" onClick={() => setEditingItem(item)}>{t.admin.edit}</button>
                  <button className="btn btn-outline btn-sm" onClick={() => handleDeleteItem(item.id)}>{t.admin.delete}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {editingItem && (
          <form onSubmit={handleSaveItem} className="admin-card" style={{ marginTop: 16 }}>
            <div className="form-grid">
              <div className="field"><label>{t.admin.category}</label>
                <select value={editingItem.category_id} onChange={(e) => setEditingItem({ ...editingItem, category_id: e.target.value })}>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name_en}</option>)}
                </select>
              </div>
              <div className="field"><label>{t.admin.price}</label>
                <input type="number" value={editingItem.price} onChange={(e) => setEditingItem({ ...editingItem, price: e.target.value })} required />
              </div>
              <div className="field"><label>{t.admin.image}</label>
                <input value={editingItem.image_url} onChange={(e) => setEditingItem({ ...editingItem, image_url: e.target.value })} />
              </div>
              <div className="field"><label>{t.admin.available}</label>
                <select value={editingItem.is_available ? "1" : "0"} onChange={(e) => setEditingItem({ ...editingItem, is_available: e.target.value === "1" })}>
                  <option value="1">{t.admin.available}</option>
                  <option value="0">—</option>
                </select>
              </div>
            </div>

            <AdminLangTabs value={tab} onChange={setTab} />
            <div className="field">
              <label>{t.admin.dishName}</label>
              <input
                value={editingItem[`name_${tab}`]}
                onChange={(e) => setEditingItem({ ...editingItem, [`name_${tab}`]: e.target.value })}
                required
              />
            </div>
            <div className="field">
              <label>{t.admin.description}</label>
              <textarea
                value={editingItem[`description_${tab}`]}
                onChange={(e) => setEditingItem({ ...editingItem, [`description_${tab}`]: e.target.value })}
              />
            </div>

            <div className="admin-row-actions">
              <button type="submit" className="btn btn-primary">{t.admin.save}</button>
              <button type="button" className="btn btn-outline" onClick={() => setEditingItem(null)}>{t.admin.cancel}</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
