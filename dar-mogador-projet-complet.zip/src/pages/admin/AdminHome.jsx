import { useEffect, useState } from "react";
import { useLang } from "../../i18n/LanguageContext";
import { getHome, updateHome } from "../../lib/content";
import AdminLangTabs from "../../components/admin/AdminLangTabs";

export default function AdminHome() {
  const { t } = useLang();
  const [form, setForm] = useState(null);
  const [tab, setTab] = useState("ar");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getHome().then(setForm);
  }, []);

  if (!form) return null;

  function field(key) {
    return `${key}_${tab}`;
  }

  async function handleSave(e) {
    e.preventDefault();
    await updateHome(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div>
      <div className="admin-header">
        <h1 style={{ margin: 0 }}>{t.admin.home}</h1>
        {saved && <span className="badge badge-approved">{t.admin.saved}</span>}
      </div>

      <AdminLangTabs value={tab} onChange={setTab} />

      <form onSubmit={handleSave} className="admin-card">
        <div className="field">
          <label>Hero title</label>
          <input
            value={form[field("hero_title")] || ""}
            onChange={(e) => setForm({ ...form, [field("hero_title")]: e.target.value })}
          />
        </div>
        <div className="field">
          <label>Hero subtitle</label>
          <input
            value={form[field("hero_subtitle")] || ""}
            onChange={(e) => setForm({ ...form, [field("hero_subtitle")]: e.target.value })}
          />
        </div>
        <div className="field">
          <label>Hero description</label>
          <textarea
            value={form[field("hero_description")] || ""}
            onChange={(e) => setForm({ ...form, [field("hero_description")]: e.target.value })}
          />
        </div>
        <div className="field">
          <label>Our-story teaser (shown on homepage)</label>
          <textarea
            value={form[field("story_teaser")] || ""}
            onChange={(e) => setForm({ ...form, [field("story_teaser")]: e.target.value })}
          />
        </div>
        <button type="submit" className="btn btn-primary">{t.admin.save}</button>
      </form>
    </div>
  );
}
