import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useLang } from "../../i18n/LanguageContext";
import { signIn, demoCredentials } from "../../lib/auth";
import { isSupabaseConfigured } from "../../lib/supabase";

export default function AdminLogin() {
  const { t } = useLang();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await signIn(email, password);
      navigate("/admin");
    } catch {
      setError(t.admin.loginError);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="admin-login-shell" dir="ltr">
      <div className="admin-login-card">
        <h2 style={{ marginBottom: 24 }}>{t.admin.login}</h2>
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">{t.admin.email}</label>
            <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="field">
            <label htmlFor="password">{t.admin.password}</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <p className="field-error">{error}</p>}
          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {t.admin.loginBtn}
          </button>
        </form>
        {!isSupabaseConfigured && (
          <p style={{ fontSize: "0.8rem", color: "rgba(28,23,18,0.55)", marginTop: 18 }}>
            Demo mode credentials: <strong>{demoCredentials.email}</strong> /{" "}
            <strong>{demoCredentials.password}</strong>
            <br />
            Connect Supabase (see README) for real, secure admin accounts.
          </p>
        )}
      </div>
    </div>
  );
}
