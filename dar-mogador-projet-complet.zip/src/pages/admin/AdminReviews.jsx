import { useEffect, useState } from "react";
import { useLang } from "../../i18n/LanguageContext";
import { getAllReviews, setReviewApproval, deleteReview } from "../../lib/content";

export default function AdminReviews() {
  const { t } = useLang();
  const [reviews, setReviews] = useState([]);

  async function refresh() {
    setReviews(await getAllReviews());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function toggleApproval(r) {
    await setReviewApproval(r.id, !r.approved);
    refresh();
  }

  async function handleDelete(id) {
    if (!confirm(t.admin.confirmDelete)) return;
    await deleteReview(id);
    refresh();
  }

  return (
    <div>
      <div className="admin-header">
        <h1 style={{ margin: 0 }}>{t.admin.reviewsMgmt}</h1>
      </div>
      <p style={{ fontSize: "0.85rem", color: "rgba(28,23,18,0.6)", maxWidth: "60ch" }}>
        Every review submitted on the site lands here first. Approve the ones you want visible —
        they'll appear on the homepage immediately, in whichever language they were written.
      </p>
      <div className="admin-card">
        {reviews.length === 0 ? (
          <p>—</p>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>{t.reviews.name}</th>
                <th>{t.reviews.rating}</th>
                <th>{t.reviews.comment}</th>
                <th>Lang</th>
                <th>{t.admin.status}</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {reviews.map((r) => (
                <tr key={r.id}>
                  <td>{r.name}</td>
                  <td>{"★".repeat(r.rating)}</td>
                  <td style={{ maxWidth: 320 }}>{r.comment}</td>
                  <td>{r.language?.toUpperCase()}</td>
                  <td>
                    <span className={r.approved ? "badge badge-approved" : "badge badge-pending"}>
                      {r.approved ? t.admin.approved : t.admin.pending}
                    </span>
                  </td>
                  <td className="admin-row-actions">
                    <button className="btn btn-outline btn-sm" onClick={() => toggleApproval(r)}>
                      {r.approved ? t.admin.unapprove : t.admin.approve}
                    </button>
                    <button className="btn btn-outline btn-sm" onClick={() => handleDelete(r.id)}>{t.admin.delete}</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
