import { useEffect, useMemo, useState } from "react";
import { useLang, pick } from "../i18n/LanguageContext";
import { getCategories, getMenuItems } from "../lib/content";
import SEO from "../components/SEO";
import Loader from "../components/Loader";

export default function Menu() {
  const { t, lang } = useLang();
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [active, setActive] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getCategories(), getMenuItems()]).then(([c, i]) => {
      setCategories(c);
      setItems(i.filter((it) => it.is_available !== false));
      setLoading(false);
    });
  }, []);

  const filtered = useMemo(
    () => (active === "all" ? items : items.filter((i) => i.category_id === active)),
    [active, items]
  );

  if (loading) return <Loader />;

  return (
    <>
      <SEO title={t.menu.title} />
      <section className="page-hero">
        <div className="container">
          <h1>{t.menu.title}</h1>
        </div>
      </section>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          {items.length === 0 ? (
            <p>{t.menu.empty}</p>
          ) : (
            <>
              <div className="menu-tabs">
                <button
                  className={`menu-tab ${active === "all" ? "active" : ""}`}
                  onClick={() => setActive("all")}
                >
                  {lang === "ar" ? "الكل" : lang === "fr" ? "Tout" : "All"}
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    className={`menu-tab ${active === c.id ? "active" : ""}`}
                    onClick={() => setActive(c.id)}
                  >
                    {pick(c, "name", lang)}
                  </button>
                ))}
              </div>
              <div className="menu-grid">
                {filtered.map((item) => (
                  <div className="menu-item" key={item.id}>
                    <div className="menu-item-figure">
                      <img src={item.image_url} alt="" />
                    </div>
                    <div className="menu-item-body">
                      <div className="menu-item-top">
                        <h3>{pick(item, "name", lang)}</h3>
                        <span className="menu-item-price">{item.price} {t.menu.currency}</span>
                      </div>
                      <p>{pick(item, "description", lang)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </section>
    </>
  );
}
