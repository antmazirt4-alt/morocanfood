import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useLang, pick } from "../i18n/LanguageContext";
import { getSettings, getHome, getMenuItems, getCategories } from "../lib/content";
import SEO from "../components/SEO";
import Loader from "../components/Loader";
import ReviewsSection from "../components/ReviewsSection";
import { fallbackAbout } from "../data/fallbackContent";

export default function Home() {
  const { t, lang } = useLang();
  const [settings, setSettings] = useState(null);
  const [home, setHome] = useState(null);
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    Promise.all([getSettings(), getHome(), getMenuItems(), getCategories()]).then(
      ([s, h, i, c]) => {
        setSettings(s);
        setHome(h);
        setItems(i);
        setCategories(c);
      }
    );
  }, []);

  if (!settings || !home) return <Loader />;

  const featured = items.slice(0, 3);
  const catName = (id) => pick(categories.find((c) => c.id === id), "name", lang);

  return (
    <>
      <SEO
        title={`${pick(settings, "restaurant_name", lang)} — ${pick(home, "hero_subtitle", lang)}`}
        description={pick(home, "hero_description", lang)}
      />

      <section className="hero">
        <div className="container hero" style={{ padding: 0 }}>
          <div>
            <div className="hero-eyebrow">{pick(settings, "tagline", lang)}</div>
            <h1>{pick(home, "hero_title", lang)}</h1>
            <p className="hero-desc">{pick(home, "hero_description", lang)}</p>
            <div className="hero-actions">
              <Link to="/menu" className="btn btn-primary">{t.home.cta}</Link>
              <Link to="/contact" className="btn btn-outline">{t.home.reserveCta}</Link>
            </div>
          </div>
          <div className="hero-figure">
            <img
              src="https://images.unsplash.com/photo-1560611767-654c47b46d16?q=80&w=1000&auto=format&fit=crop"
              alt=""
            />
          </div>
        </div>
      </section>

      <div className="zellige-rule" />

      <section className="section">
        <div className="container about-grid">
          <div className="about-figure">
            <img src={fallbackAbout.photo_url} alt="" />
          </div>
          <div>
            <div className="hero-eyebrow">{t.home.storyTeaser}</div>
            <h2>{pick(settings, "restaurant_name", lang)}</h2>
            <p>{pick(home, "story_teaser", lang)}</p>
            <Link to="/about" className="btn btn-outline btn-sm">{t.home.storyLink}</Link>
          </div>
        </div>
      </section>

      <section className="section section-alt">
        <div className="container">
          <div className="section-head">
            <h2>{t.home.menuTeaser}</h2>
          </div>
          <div className="menu-grid">
            {featured.map((item) => (
              <div className="menu-item" key={item.id}>
                <div className="menu-item-figure">
                  <img src={item.image_url} alt="" />
                </div>
                <div className="menu-item-body">
                  <div className="menu-item-top">
                    <h3>{pick(item, "name", lang)}</h3>
                    <span className="menu-item-price">{item.price} {t.menu.currency}</span>
                  </div>
                  <p>{catName(item.category_id)}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="center mt-lg">
            <Link to="/menu" className="btn btn-gold">{t.home.cta}</Link>
          </div>
        </div>
      </section>

      <ReviewsSection />
    </>
  );
}
