import { useEffect, useState } from "react";
import { useLang, pick } from "../i18n/LanguageContext";
import { getSettings } from "../lib/content";
import SEO from "../components/SEO";
import Loader from "../components/Loader";
import ReservationForm from "../components/ReservationForm";

export default function Contact() {
  const { t, lang } = useLang();
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  if (!settings) return <Loader />;

  return (
    <>
      <SEO title={t.contact.title} description={pick(settings, "tagline", lang)} />
      <section className="page-hero">
        <div className="container">
          <h1>{t.reservation.title}</h1>
          <p className="hero-desc">{t.reservation.subtitle}</p>
        </div>
      </section>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container contact-grid">
          <div>
            <ReservationForm whatsappNumber={settings.whatsapp_number} />
          </div>
          <div className="contact-card">
            <h2 style={{ fontSize: "1.4rem" }}>{t.contact.title}</h2>
            <div className="contact-row">
              <span className="contact-row-label">{t.contact.address}</span>
              <span>{pick(settings, "address", lang)}</span>
            </div>
            <div className="contact-row">
              <span className="contact-row-label">{t.contact.hours}</span>
              <span>{pick(settings, "hours", lang)}</span>
            </div>
            <div className="contact-row">
              <span className="contact-row-label">{t.contact.phone}</span>
              <a href={`tel:${settings.phone_display?.replace(/\s/g, "")}`}>{settings.phone_display}</a>
            </div>
            {settings.map_embed_url && (
              <div>
                <div className="contact-row-label" style={{ marginBottom: 10 }}>{t.contact.findUs}</div>
                <div className="contact-map">
                  <iframe src={settings.map_embed_url} title="map" loading="lazy" />
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
