import { Link } from "react-router-dom";
import { useLang } from "../i18n/LanguageContext";

export default function NotFound() {
  const { t } = useLang();
  return (
    <div className="not-found">
      <h1>404</h1>
      <p>{t.messages.notFound}</p>
      <Link to="/" className="btn btn-primary">{t.messages.backHome}</Link>
    </div>
  );
}
