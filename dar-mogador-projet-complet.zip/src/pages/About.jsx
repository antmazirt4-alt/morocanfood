import { useEffect, useState } from "react";
import { useLang, pick } from "../i18n/LanguageContext";
import { getAbout, getGallery } from "../lib/content";
import SEO from "../components/SEO";
import Loader from "../components/Loader";

export default function About() {
  const { t, lang } = useLang();
  const [about, setAbout] = useState(null);
  const [gallery, setGallery] = useState([]);

  useEffect(() => {
    getAbout().then(setAbout);
    getGallery().then(setGallery);
  }, []);

  if (!about) return <Loader />;

  return (
    <>
      <SEO title={pick(about, "title", lang)} description={pick(about, "body", lang).slice(0, 150)} />
      <section className="page-hero">
        <div className="container">
          <h1>{pick(about, "title", lang)}</h1>
        </div>
      </section>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container about-grid">
          <div className="about-figure">
            <img src={about.photo_url} alt="" />
          </div>
          <div className="about-body">
            <p>{pick(about, "body", lang)}</p>
          </div>
        </div>
      </section>

      {gallery.length > 0 && (
        <section className="section section-alt" style={{ paddingTop: 0 }}>
          <div className="container">
            <div className="gallery-grid">
              {gallery.map((g) => (
                <div className="gallery-item" key={g.id}>
                  <img src={g.image_url} alt="" />
                  {pick(g, "caption", lang) && (
                    <div className="gallery-caption">{pick(g, "caption", lang)}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
