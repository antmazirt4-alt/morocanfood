import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { translations, LANGUAGES } from "./translations";

const STORAGE_KEY = "dar-mogador-lang";
const VALID_CODES = LANGUAGES.map((l) => l.code);

function detectInitialLang(defaultLanguage) {
  if (typeof window === "undefined") return defaultLanguage || "fr";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored && VALID_CODES.includes(stored)) return stored;
  const browser = (window.navigator.language || "fr").slice(0, 2);
  if (VALID_CODES.includes(browser)) return browser;
  return defaultLanguage || "fr";
}

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [lang, setLangState] = useState(() => detectInitialLang("fr"));

  useEffect(() => {
    const meta = LANGUAGES.find((l) => l.code === lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = meta?.dir || "ltr";
    window.localStorage.setItem(STORAGE_KEY, lang);
  }, [lang]);

  function setLang(code) {
    if (VALID_CODES.includes(code)) setLangState(code);
  }

  const value = useMemo(
    () => ({
      lang,
      setLang,
      languages: LANGUAGES,
      t: translations[lang],
    }),
    [lang]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within a LanguageProvider");
  return ctx;
}

// Picks a localized field from a record shaped like { field_ar, field_fr, field_en }.
export function pick(record, field, lang) {
  if (!record) return "";
  return record[`${field}_${lang}`] || record[`${field}_fr`] || record[`${field}_en`] || record[`${field}_ar`] || "";
}
